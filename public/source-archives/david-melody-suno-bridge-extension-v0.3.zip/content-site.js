// content-site.js
const DAVID_MELODY_BRIDGE_CONTENT_SITE_VERSION = "0.4.0";
const STORAGE_KEY = "DAVID_MELODY_SUNO_BRIDGE_PENDING";
const ALLOWED_SOURCES = ["playlist-maker", "david-melody-studio", "david-melody-ai-studio"];
let lastSavedSignature = "";

function announceBridgeReady() {
  window.postMessage({
    source: "suno-bridge-extension",
    type: "EXTENSION_READY",
    version: DAVID_MELODY_BRIDGE_CONTENT_SITE_VERSION,
    href: location.href
  }, "*");
}

function normalizePayload(payload) {
  if (!payload || typeof payload !== "object") return null;
  const songTitle = String(payload.songTitle || payload.title || "").trim();
  const sunoStylePrompt = String(payload.sunoStylePrompt || payload.style || payload.stylePrompt || "").trim();
  const lyrics = String(payload.lyrics || payload.lyric || "").trim();
  if (!songTitle || !sunoStylePrompt || !lyrics) return null;
  return { ...payload, songTitle, sunoStylePrompt, lyrics };
}

function signature(payload) {
  return JSON.stringify({
    songTitle: payload.songTitle,
    sunoStylePrompt: payload.sunoStylePrompt,
    lyrics: payload.lyrics
  });
}

async function savePayload(rawPayload, via = "message") {
  const payload = normalizePayload(rawPayload);
  if (!payload) {
    window.postMessage({
      source: "suno-bridge-extension",
      type: "SEND_TO_SUNO_BRIDGE_RESULT",
      success: false,
      error: "제목 / Style of Music / Lyrics가 모두 있어야 합니다.",
      via
    }, "*");
    return;
  }

  const sig = signature(payload);
  if (sig === lastSavedSignature && Date.now() - (window.__lastSunoBridgeSaveAt || 0) < 800) return;
  lastSavedSignature = sig;
  window.__lastSunoBridgeSaveAt = Date.now();

  try {
    const res = await chrome.runtime.sendMessage({
      action: "SAVE_PENDING_SONG",
      data: { ...payload, sentFrom: location.href, via }
    });
    window.postMessage({
      source: "suno-bridge-extension",
      type: "SEND_TO_SUNO_BRIDGE_RESULT",
      success: !!(res && res.success),
      error: res && res.error,
      via
    }, "*");
  } catch (err) {
    window.postMessage({
      source: "suno-bridge-extension",
      type: "SEND_TO_SUNO_BRIDGE_RESULT",
      success: false,
      error: "확장프로그램과 통신할 수 없습니다. chrome://extensions에서 확장 새로고침 후 Studio 페이지도 새로고침하세요.",
      via
    }, "*");
  }
}

window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  const msg = event.data;
  if (!msg || !ALLOWED_SOURCES.includes(msg.source)) return;
  if (msg.type === "SEND_TO_SUNO_BRIDGE") savePayload(msg.payload, "postMessage");
});

window.addEventListener("david-melody-send-to-suno-bridge", (event) => {
  savePayload(event.detail, "customEvent");
});

function readLocalStoragePayload() {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    const parsed = JSON.parse(raw);
    if (parsed && parsed.payload) savePayload(parsed.payload, "localStorage");
  } catch (_) {}
}

window.addEventListener("storage", (event) => {
  if (event.key === STORAGE_KEY) readLocalStoragePayload();
});

announceBridgeReady();
window.addEventListener("DOMContentLoaded", () => {
  announceBridgeReady();
  readLocalStoragePayload();
});
setTimeout(announceBridgeReady, 500);
setTimeout(readLocalStoragePayload, 700);
setInterval(readLocalStoragePayload, 1500);
