# 다윗멜로디 Suno Studio Unified - Final 3 Tools

최종 구조는 요청대로 3개만 남겼습니다.

1. 다윗멜로디 AI Studio v6.2
   - 찬양트로트 v5, Suno Prompt Generator, Suno Trot Lyrics, Mobile Offline 계열 기능을 v6.2 중심으로 편입
   - 실행 위치: `/tools/david-melody-ai-studio-v6-2.html`

2. GPT 흥행 플리 생성기
   - Next.js 메인 앱
   - YouTube 분석, 흥행 플레이리스트 생성, AI 가사 생성, SEO, 이미지 프롬프트, 결과 내보내기 담당
   - 실행 위치: `/`

3. Suno Bridge Extension
   - Chrome 확장프로그램
   - 위치: `public/extensions/suno-bridge-extension`

## 실행

```bash
npm install
npm run dev
```

## 접속

- 메인: http://localhost:3000
- 최종 도구 목록: http://localhost:3000/tools
