// content-site.js
// 다윗멜로디 AI Studio 웹페이지(로컬 HTML 포함)에 주입됩니다.
// 웹페이지가 window.postMessage로 보낸 곡 데이터를 받아
// 확장프로그램(background.js)에 저장 요청을 전달합니다.
//
// 웹페이지 쪽에서는 아래 형태로 메시지를 보내면 됩니다:
//
// window.postMessage({
//   source: "playlist-maker",
//   type: "SEND_TO_SUNO_BRIDGE",
//   payload: {
//     songTitle: "노래 제목",
//     sunoStylePrompt: "Style of Music 텍스트",
//     lyrics: "가사 전체 텍스트"
//   }
// }, "*");

window.addEventListener("message", async (event) => {
  // 같은 탭(자기 페이지)에서 온 메시지만 처리
  if (event.source !== window) return;

  const msg = event.data;
  if (!msg || !["playlist-maker", "david-melody-studio"].includes(msg.source)) return;

  if (msg.type === "SEND_TO_SUNO_BRIDGE") {
    const payload = msg.payload || {};
    if (!payload.songTitle || !payload.sunoStylePrompt || !payload.lyrics) {
      window.postMessage(
        {
          source: "suno-bridge-extension",
          type: "SEND_TO_SUNO_BRIDGE_RESULT",
          success: false,
          error: "songTitle / sunoStylePrompt / lyrics 가 모두 필요합니다.",
        },
        "*"
      );
      return;
    }

    try {
      const res = await chrome.runtime.sendMessage({
        action: "SAVE_PENDING_SONG",
        data: payload,
      });
      window.postMessage(
        {
          source: "suno-bridge-extension",
          type: "SEND_TO_SUNO_BRIDGE_RESULT",
          success: !!(res && res.success),
          error: res && res.error,
        },
        "*"
      );
    } catch (err) {
      window.postMessage(
        {
          source: "suno-bridge-extension",
          type: "SEND_TO_SUNO_BRIDGE_RESULT",
          success: false,
          error: "확장프로그램과 통신할 수 없습니다. 확장이 설치/활성화되어 있는지 확인해주세요.",
        },
        "*"
      );
    }
  }
});

// 페이지가 로드되면, 확장프로그램이 설치되어 있다는 걸 페이지가 감지할 수 있도록 신호를 보냄
window.postMessage({ source: "suno-bridge-extension", type: "EXTENSION_READY" }, "*");
