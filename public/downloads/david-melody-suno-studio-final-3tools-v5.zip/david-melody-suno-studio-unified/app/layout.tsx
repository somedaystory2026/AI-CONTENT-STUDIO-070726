import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "다윗멜로디 Suno Studio Unified",
  description: "Suno, Playlist, Trot, CCM, YouTube SEO 통합 AI 음악 제작 스튜디오",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ko" className="h-full antialiased">
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}
